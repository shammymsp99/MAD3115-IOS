//
//  instructionsVC.swift
//  PJ
//
//  Created by Shashank Preetham on 2018-11-03.
//  Copyright © 2018 shashank Machani. All rights reserved.
//

import UIKit
import WebKit

class instructionsVC: UIViewController {

    @IBOutlet weak var myWebView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadFromFile()
    }
    
    func loadFromFile()
    {
        let localfilePath = Bundle.main.url(forResource: "help", withExtension: "html");
        let myRequest = URLRequest(url: localfilePath!);
        self.myWebView.load(myRequest);
    }

}
