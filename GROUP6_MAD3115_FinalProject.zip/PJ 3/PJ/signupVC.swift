
import UIKit

class signupVC: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var segGender: UISegmentedControl!
    
      var gender: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtName.text = ""
        txtEmail.text = ""
        txtPassword.text = ""
    }
    override func viewWillAppear(_ animated: Bool) {
        txtName.text = ""
        txtEmail.text = ""
        txtPassword.text = ""
    }
    @IBAction func btnSubmit(_ sender: UIButton) {
        //creating a format for the values  to display...!!!
        
        
//        let ud = UserDefaults.standard
//        let userName = ud.string(forKey: "userName")
//        let Email = ud.string(forKey: "Email")
//        let Password = ud.string(forKey: "Password")
//        txtEmail.text = Email
//        txtPassword.text = Password
//        txtName.text = userName
        
        var data : String = txtName.text!
        data += "\n" + txtPassword.text!
        data += "\n" + txtEmail.text!
        switch segGender.selectedSegmentIndex {
        case 0:
            data += "\n Male"
            gender = "Male"
        case 1:
            data += "\n Female"
            gender = "Female"
        case 2:
            data += "\n No Disclosure"
            gender = "No Disclosure"
        default:
            data += "\n No Disclosure"
            gender = "No Disclosure"
        }
        // sending data for another view controllersss.....!!!!!!
        let ud =  UserDefaults.standard
            ud.set(txtEmail.text, forKey: "Email")
            ud.set(txtPassword.text, forKey: "Password")
            ud.set(txtName.text, forKey: "userName")
//        confirmation alert for the new user....!!!
        let infoAlert = UIAlertController(title: "Confirm details", message: data, preferredStyle: .alert)
        
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayHomeVC()}))
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(infoAlert, animated: true, completion: nil)
       /////
}
    func displayHomeVC(){
        let newUser = User(txtName.text!, txtEmail.text!, txtPassword.text!, self.gender)
        
        if User.addUser(newUser: newUser){
//            let tabbar = (storyboard?.instantiateViewController(withIdentifier: "tabbar") as? UITabBarController)
//            self.present(tabbar!, animated: true, completion: nil)
            let mainSb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let signUpVC = mainSb.instantiateViewController(withIdentifier: "LoginScene")
            navigationController?.pushViewController(signUpVC, animated: true)
        }
        else{
            let infoAlert = UIAlertController(title: "Unsuccessful", message: "Account Creation Unsuccessful", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnLogin(_ sender: UIButton) {
        //
        let mainSb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpVC = mainSb.instantiateViewController(withIdentifier: "LoginScene")
        navigationController?.pushViewController(signUpVC, animated: true)
    }
}
