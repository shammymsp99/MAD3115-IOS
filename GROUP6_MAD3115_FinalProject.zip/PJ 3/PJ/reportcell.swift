//
//  reportcell.swift
//  PJ
//
//  Created by Shashank Preetham on 2018-11-17.
//  Copyright © 2018 shashank Machani. All rights reserved.
//

import UIKit

class reportcell: UITableViewCell {

    @IBOutlet weak var carcolorlabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()//Prepares the receiver for service after it has been loaded from an Interface Builder archive, or nib file.
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
