//
//  supportVC.swift
//  PJ
//
//  Created by Shashank Preetham on 2018-11-03.
//  Copyright © 2018 shashank Machani. All rights reserved.
//

import UIKit

class supportVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //showAlert()
        // Do any additional setup after loading the view.
        
}
    
    override func viewDidAppear(_ animated: Bool) {
        showAlert()
    }
   
    func showAlert(){
        let attributedString = NSAttributedString(string: "+1 1234567890                                              9:00 AM - 8:00 PM ET M-F                                             Email: pritam.world@gmail.com", attributes: [NSAttributedString.Key.font : UIFont(name: "Avenir-Light", size: 20)!])
        let alert = UIAlertController(title: "Need Help ?", message: "", preferredStyle: UIAlertController.Style.alert)
        alert.setValue(attributedString, forKey: "attributedMessage")
        let alertAction = UIAlertAction(title: "OK!", style: UIAlertAction.Style.default)
        {
            (UIAlertAction) -> Void in
        }
        alert.addAction(alertAction)
        present(alert, animated: true)
        {
            () -> Void in
        }
    }
}
