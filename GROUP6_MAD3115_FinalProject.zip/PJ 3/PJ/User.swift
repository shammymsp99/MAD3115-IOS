//
//  User.swift
//  PJ
//
//  Created by Shashank Preetham on 2018-11-04.
//  Copyright © 2018 shashank Machani. All rights reserved.
//

import Foundation

class User{
 
    var name: String!
    var email: String!
    var password: String!
    var gender: String!
    
     private static var userList = [String: User]()
  
    init(){
        self.name = ""
        self.email = ""
        self.password = ""
        self.gender = ""
    }
    init(_ name: String,  _ email: String, _ password: String, _ gender: String) {
        self.name = name
        self.email = email
        self.password = password
        self.gender = gender
    }
    static func addUser(newUser: User) -> Bool {
        if self.userList[newUser.email] == nil{
            self.userList[newUser.email] = newUser
            return true
        }
        return false
    }
    static func deleteUser(newUser: User) -> Bool {
        self.userList[newUser.email] = nil
        return true
    }
    
    static func getAllUsers() -> [String: User]{
        return userList
    }
    
    static func searchUser(userEmail: String) -> User {
        if self.userList[userEmail] != nil{
            return self.userList[userEmail]!
        }
        return User()
    }
}
